/******************************************************************************
 *                       <<< CheckMailD v0.4.1 - POP3/IMAP Daemon >>>
 *                       Copyright (C) 2006 Oliver Metz, Marco Zissen 
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
  ******************************************************************************/
 
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <syslog.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdarg.h>
#include <time.h>
#include <ctype.h>


#ifdef WIN32
#include <winsock.h>
#else
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#endif

char* CFGPATH = NULL;
char* NOTIFILE = NULL;
char* BODYFILE = NULL;
char* HEADFILE = NULL;
char* EVFILE = NULL;
char* IDXFILE = NULL;
char* STATUSFILE = NULL;

#define CFGFILE_NAME 	"checkmaild.conf"
#define IDXFILE_NAME	"checkmaild.idx"
#define STATUSFILE_NAME "checkmaild.?"
#define NOTIFILE_NAME 	"checkmaild.new"
#define BODYFILE_NAME 	"maillog.body"
#define HEADFILE_NAME	"maillog.head"
#define EVFILE_NAME 	"maillog.cfg"

#if 1
char CFGPATH_DEFAULT[] = "/var/tmp/";
#define LOCK_FILE	"/var/lock/checkmaild.lock"
#define SCKFILE 	"/var/tmp/checkmaild.socket"
#define LOGFILE 	"/var/log/checkmaild.log"
#define PIDFILE 	"/var/run/checkmaild.pid"
#else
char CFGPATH_DEFAULT[] = "./";
#define LOCK_FILE "checkmaild.lock"
#define SCKFILE "checkmaild.socket"
#define LOGFILE "checkmaild.log"
#define PIDFILE "checkmaild.pid"
#endif 


#define bool char
#define true 1
#define false 0
#define PORTNUM 1011
#define SLEEP 15

// maximum number of chars in a line
#define cnRAND			78
// maximum charcters in a word
#define cnMaxWordLen	20
// maximum recv-buffer size
#define RECVBUFFER_SIZE	32767
// maximum send-buffer size
#define SENDBUFFER_SIZE	128


FILE *fd_mail;
int  nStartSpalte, nCharInLine, nCharInWord, nRead, nWrite, nStrich ; 
int  nIn, nSo, nTr; 
char  cLast; 
bool  fPre; 							//! pre-formated HTML code
bool  fHtml; 							//! HTML code
int  nCRLF = 0; 
int  nLine = 1; 
int  nRef  = 1;
int   nHyp  = 0 ;
char  sSond[355],sRef[355], sWord[85];
static enum  t_state { cNorm, cInTag, cSond, cInComment, cTrans } state ;

// pop3 and smtp commands

enum
{
	INIT, QUIT,
	USER, PASS, STAT, UIDL, TOP, DELE, RETR, RSET,
	EHLO, AUTH, MAIL, RCPT, DATA1, DATA2, DATA3,
	LOGIN, SELECT, FETCH, LOGOUT, CLOSE, FLAGS,
	UNSEEN, EXPUNGE
};

#define MAXMAIL 100													// should be the same in tuxmail.h

// account database

struct
{
	char name[32];
	char pop3[64];
	char imap[64];
	char user[64];
	char pass[64];
	char smtp[64];
	char from[64];
	char code[8];
	int  auth;
	char suser[64];
	char spass[64];
	char inbox[64];	
	int  mail_all;
	int  mail_new;
	int  mail_unread;
	int  mail_read;

}account_db[10];

// some data

char versioninfo[]="0.4.1";
FILE *fd_pid;
int slog = 0;
int pid;
char encodedstring[512], decodedstring[512];
int startdelay, intervall;
char logging, logmode, mailrd;
char online = 1;
//char mailread = 0;
int mailstatus, unread_mailstatus;
char inPOPCmd = 0;
int accounts;
int sock;
int messages, deleted_messages;
int led_status = 0;
unsigned int stringindex;
char uid[128];
long v_uid;
long m_uid;
char imap;
char header[1024];
char body[RECVBUFFER_SIZE];		// maz
char head[RECVBUFFER_SIZE];		// maz
int headersize;
char timeinfo[22];
int timeofday;
time_t tt;
char telnot, lednot, cfgnot, recvmail, ledmajor[3], ledminor, fon[3], num[13], sip[4];

// declare functions 
int TelEvent(char *fon, char *sip, char *num);
void MailEvent(int account, int mail_all, int mail_new, char*header, bool oldMail, int isInterval);
void LEDEvent(bool bOn, int unread_mails, char *ledmajor, char ledminor);
void LEDOn(int unread_mails,char *ledmajor, char ledminor);
void LEDOff(char *ledmajor);
