/******************************************************************************
 *                       <<< CheckMailD v0.4.1 - POP3/IMAP Daemon >>>
 *                       Copyright (C) 2006 Oliver Metz, Marco Zissen
 * 
 *   This program is free software; you can redistribute it and/or modify 
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version. 
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Mein Dank geht an die Autoren des tuxmail-Projects, 
 * insbesondere an Robert Spreitzer.
 * http://cvs.tuxbox.org/cgi-bin/viewcvs.cgi/tuxbox/apps/tuxbox/plugins/tuxmail/
 *-----------------------------------------------------------------------------
 * Revision 0.2  2006/01/28 12:04:23
 * - bugfix: close IMAP connection in any case
   ******************************************************************************/
#include "checkmaild.h"

/******************************************************************************
 * ReadConf (0=fail, 1=done)
 ******************************************************************************/

int ReadConf()
{
	FILE *fd_conf;
	char *ptr;
	char line_buffer[256];
	char *file = NULL;
	int loop;

	// maz - create /var/tmp/maillog.cfg if not exists
	fd_conf = fopen(EVFILE, "a");
	sprintf(line_buffer, "chmod +x %s", EVFILE);
	system(line_buffer);
	line_buffer[0] = '\0';
	fclose(fd_conf);
	// maz - end
	
	// open config
	file = (char*)malloc(strlen(CFGPATH) + strlen(CFGFILE_NAME) + 1);
	sprintf(file, "%s%s", CFGPATH, CFGFILE_NAME);

	if(!(fd_conf = fopen(file, "r+")))
	{
		syslog(LOG_DAEMON | LOG_INFO, "generate new Config, please modify and restart Daemon"); 
		printf("CheckMailD <generate new Config, please modify and restart Daemon>\n");

		if(mkdir(CFGPATH, S_IRWXU) == -1 && errno != EEXIST)
		{
			syslog(LOG_DAEMON | LOG_INFO, "could not create ConfigDir");
			printf("CheckMailD <could not create ConfigDir>\n");

			return 0;
		}

		if(!(fd_conf = fopen(file, "w")))
		{
			syslog(LOG_DAEMON | LOG_INFO, "could not create Config");
			printf("CheckMailD <could not create Config>\n");

			return 0;
		}
		
		fprintf(fd_conf, "STARTDELAY=30\n");
		fprintf(fd_conf, "INTERVALL=15\n");			
		fprintf(fd_conf, "LOGGING=Y\n");
		fprintf(fd_conf, "LOGMODE=S\n");			
		fprintf(fd_conf, "\n");														
		fprintf(fd_conf, "CFGNOTIFY=Y\n");
		fprintf(fd_conf, "RECVMSG=N\n");			
		fprintf(fd_conf, "\n");
		fprintf(fd_conf, "LEDNOTIFY=Y\n");
		fprintf(fd_conf, "LEDMAJOR=7\n");
		fprintf(fd_conf, "LEDMINOR=2\n");
		fprintf(fd_conf, "\n");			
		fprintf(fd_conf, "TELNOTIFY=N\n");			
		fprintf(fd_conf, "NUMBER=\n"); 
		fprintf(fd_conf, "SIP=\n");
		fprintf(fd_conf, "FON=\n");						
		fprintf(fd_conf, "\n");			
		fprintf(fd_conf, "NAME0=\n");
		fprintf(fd_conf, "POP30=\n");
		fprintf(fd_conf, "IMAP0=\n");
		fprintf(fd_conf, "INBOX0=\n");	
		fprintf(fd_conf, "USER0=\n");
		fprintf(fd_conf, "PASS0=\n");
		fclose(fd_conf);

		return 0;
	}

	// clear database
	memset(account_db, 0, sizeof(account_db));
	startdelay = intervall = logging = logmode = 0;

	// fill database
	while(fgets(line_buffer, sizeof(line_buffer), fd_conf))
	{
		if((ptr = strstr(line_buffer, "STARTDELAY=")))
		{
			sscanf(ptr + 11, "%d", &startdelay);
		}
		else if((ptr = strstr(line_buffer, "INTERVALL=")))
		{
			sscanf(ptr + 10, "%d", &intervall);
		}
		else if((ptr = strstr(line_buffer, "RECVMSG=")))
		{
			sscanf(ptr + 8, "%c", &recvmail);
		}
		else if((ptr = strstr(line_buffer, "LOGGING=")))
		{
			sscanf(ptr + 8, "%c", &logging);
		}
		else if((ptr = strstr(line_buffer, "LOGMODE=")))
		{
			sscanf(ptr + 8, "%c", &logmode);
		}
		else if((ptr = strstr(line_buffer, "LEDMAJOR=")))
		{
			sscanf(ptr + 9, "%s", ledmajor);
		}
		else if((ptr = strstr(line_buffer, "LEDMINOR=")))
		{
			sscanf(ptr + 9, "%c", &ledminor);
		}
		else if((ptr = strstr(line_buffer, "TELNOTIFY=")))
		{
			sscanf(ptr + 10, "%c", &telnot);
		}
		else if((ptr = strstr(line_buffer, "LEDNOTIFY=")))
		{
			sscanf(ptr + 10, "%c", &lednot);
		}
		else if((ptr = strstr(line_buffer, "CFGNOTIFY=")))
		{
			sscanf(ptr + 10, "%c", &cfgnot);
		}
		else if((ptr = strstr(line_buffer, "NUMBER=")))
		{
			sscanf(ptr + 7, "%s", num);
		}
		else if((ptr = strstr(line_buffer, "SIP=")))
		{
			sscanf(ptr + 4, "%s", sip);
		}
		else if((ptr = strstr(line_buffer, "FON=")))
		{
			sscanf(ptr + 4, "%s", fon);
		}
		else if((ptr = strstr(line_buffer, "NAME")) && (*(ptr+5) == '='))
		{
			char index = *(ptr+4);
			if((index >= '0') && (index <= '9'))
			{
				sscanf(ptr + 6, "%s", account_db[index-'0'].name);
			}
		}
		else if((ptr = strstr(line_buffer, "POP3")) && (*(ptr+5) == '='))
		{
			char index = *(ptr+4);
			if((index >= '0') && (index <= '9'))
			{
				sscanf(ptr + 6, "%s", account_db[index-'0'].pop3);
			}
		}
		else if((ptr = strstr(line_buffer, "IMAP")) && (*(ptr+5) == '='))
		{
			char index = *(ptr+4);
			if((index >= '0') && (index <= '9'))
			{
				sscanf(ptr + 6, "%s", account_db[index-'0'].imap);
			}
		}
		else if((ptr = strstr(line_buffer, "USER")) && (*(ptr+5) == '='))
		{
			char index = *(ptr+4);
			if((index >= '0') && (index <= '9'))
			{
				sscanf(ptr + 6, "%s", account_db[index-'0'].user);
			}
		}
		else if((ptr = strstr(line_buffer, "PASS")) && (*(ptr+5) == '='))
		{
			char index = *(ptr+4);
			if((index >= '0') && (index <= '9'))
			{
				sscanf(ptr + 6, "%s", account_db[index-'0'].pass);
			}
		}
		else if((ptr = strstr(line_buffer, "INBOX")) && (*(ptr+6) == '='))
		{
			char index = *(ptr+5);
			if((index >= '0') && (index <= '9'))
			{
				sscanf(ptr + 7, "%s", account_db[index-'0'].inbox);
			}
		}			
	}

	// check for update
	if(!startdelay || !intervall || !logging || !logmode  || !recvmail)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "missing Param(s), update Config") : printf("CheckMailD <missing Param(s), update Config>\n");

		rewind(fd_conf);

		if(!startdelay)
		{
			startdelay = 30;
		}

		if(!recvmail)
		{
			recvmail = 'Y';
		}
		
		if(!intervall)
		{
			intervall = 15;
		}

		if(!logging)
		{
			logging = 'Y';
		}

		if(!logmode)
		{
			logmode = 'S';
		}
		
		if(!telnot)
		{
			logmode = 'N';
		}

		fprintf(fd_conf, "STARTDELAY=%d\n", startdelay);
		fprintf(fd_conf, "INTERVALL=%d\n\n", intervall);
		fprintf(fd_conf, "LOGGING=%c\n", logging);
		fprintf(fd_conf, "LOGMODE=%c\n", logmode);
		fprintf(fd_conf, "TELNOTIFY=%c\n\n", telnot);
		fprintf(fd_conf, "LEDNOTIFY=%c\n\n", lednot);
		fprintf(fd_conf, "CFGNOTIFY=%c\n\n", cfgnot);
		fprintf(fd_conf, "RECVMSG=%c\n\n", recvmail);
		
		for(loop = 0; loop < 10; loop++)
		{
			fprintf(fd_conf, "\nNAME%d=%s\n", loop, account_db[loop].name);
			fprintf(fd_conf, "POP3%d=%s\n", loop, account_db[loop].pop3);
			fprintf(fd_conf, "IMAP%d=%s\n", loop, account_db[loop].imap);
			fprintf(fd_conf, "USER%d=%s\n", loop, account_db[loop].user);
			fprintf(fd_conf, "PASS%d=%s\n", loop, account_db[loop].pass);
			fprintf(fd_conf, "INBOX%d=%s\n", loop, account_db[loop].inbox);
							
			if(!account_db[loop + 1].name[0])
			{
				break;
			}
		}
	}

	fclose(fd_conf);

	// check config
	if(startdelay < 1 || startdelay > 60)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "STARTDELAY=%d out of Range, set to \"30\"", startdelay) : printf("CheckMailD <STARTDELAY=%d out of Range, set to \"30\">\n", startdelay);

		startdelay = 30;
	}		
	
	if(!intervall)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "INTERVALL=0, check Account(s) and Exit") : printf("CheckMailD <INTERVALL=0, check Account(s) and Exit>\n");
	}
	else if(intervall < 1 || intervall > 120)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "INTERVALL=%d out of Range, set to \"15\"", intervall) : printf("CheckMailD <INTERVALL=%d out of Range, set to \"15\">\n", intervall);			
		intervall = 15;
	}
	
	if(recvmail != 'Y' && recvmail != 'N' )
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "RECVMSG=%c invalid, set to \"N\"", recvmail) : printf("CheckMailD <RECVMSG=%c invalid, set to \"N\">\n", recvmail);
		recvmail = 'N';
	}
	
	if(logging != 'Y' && logging != 'N')
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "LOGGING=%c invalid, set to \"N\"", logging) : printf("CheckMailD <LOGGING=%c invalid, set to \"N\">\n", logging);
		logging = 'N';
	}

	if(logmode != 'A' && logmode != 'S')
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "LOGMODE=%c invalid, set to \"S\"", logmode) : printf("CheckMailD <LOGMODE=%c invalid, set to \"S\">\n", logmode);

		logmode = 'S';
	}
	if( !isdigit(ledmajor[0]))
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "LEDMAJOR=%s invalid, set to \"7\"", ledmajor) : printf("CheckMailD <LEDMAJOR=%s invalid, set to \"7\">\n", ledmajor);
		sprintf(ledmajor, "7");	
	}
	if( !isdigit(ledminor) || sizeof(ledminor) != 1)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "LEDMINOR=%c invalid, set to \"2\"", ledminor) : printf("CheckMailD <LEDMINOR=%c invalid, set to \"2\">\n", ledminor);

		ledminor = '2';
	}
	if(cfgnot != 'N' && cfgnot != 'Y')
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "CFGNOTIFY=%c invalid, set to \"Y\"", cfgnot) : printf("CheckMailD <CFGNOTIFY=%c invalid, set to \"Y\">\n", cfgnot);
		cfgnot = 'Y';
	}		
	if(lednot != 'N' && lednot != 'Y')
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "LEDNOTIFY=%c invalid, set to \"Y\"", lednot) : printf("CheckMailD <LEDNOTIFY=%c invalid, set to \"Y\">\n", lednot);
		lednot = 'Y';
	}		
	if(telnot != 'N' && telnot != 'Y')
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "TELNOTIFY=%c invalid, set to \"N\"", telnot) : printf("CheckMailD <TELNOTIFY=%c invalid, set to \"N\">\n", telnot);
		telnot = 'N';
	}				
	if (telnot == 'Y')
	{
		unsigned int pos = 0;
		while(pos <= strlen(sip) && isdigit( sip[pos]))
		pos++;
		if (pos > 0 && pos != strlen(sip))
		{
			slog ? syslog(LOG_DAEMON | LOG_INFO, "SIP=%s out of Range, set to \"121\"", sip) : printf("CheckMailD <SIP=%s out of Range, set to \"121\">\n", sip);
			sprintf(sip, "121");
		}
		int temp = atoi(fon);
		if(temp < 1 || temp > 60)
		{
			slog ? syslog(LOG_DAEMON | LOG_INFO, "FON=%s out of Range, set to \"1\"", fon) : printf("CheckMailD <FON=%s out of Range, set to \"1\">\n", fon);
			sprintf(fon, "1");
		}
		
		pos = 0;
		while(pos < strlen(num) && isdigit( num[pos]))
		pos++;
		if (pos > 0 && pos != strlen(num))
		{
			slog ? syslog(LOG_DAEMON | LOG_INFO, "NUMBER=%s out of Range, set to \"\"", num) : printf("CheckMailD <NUMBER=%s out of Range, set to \"\">\n", num);
			sprintf(num, " ");
		}
	}

	accounts = 0;

	for(loop = 0; loop <= 9; loop++)
	{
		if(account_db[loop].name[0] && (account_db[loop].pop3[0] || account_db[loop].imap[0]) && account_db[loop].user[0] && account_db[loop].pass[0])
		{
			accounts++;
		}
		else
		{
			break;
		}
	}
	
	if(accounts)
	{
		if(logging == 'N')
		{
			slog ? syslog(LOG_DAEMON | LOG_INFO, "check %d Account(s) every %dmin without Logging", accounts, intervall) : printf("CheckMailD <check %d Account(s) every %dmin without Logging>\n", accounts, intervall);
		}
		else if(logmode == 'A')
		{
			slog ? syslog(LOG_DAEMON | LOG_INFO, "check %d Account(s) every %dmin with Logging in Append-Mode", accounts, intervall) : printf("CheckMailD <check %d Account(s) every %dmin with Logging in Append-Mode>\n", accounts, intervall);
		}
		else
		{
			slog ? syslog(LOG_DAEMON | LOG_INFO, "check %d Account(s) every %dmin with Logging in Single-Mode", accounts, intervall) : printf("CheckMailD <check %d Account(s) every %dmin with Logging in Single-Mode>\n", accounts, intervall);
		}

		return 1;
	}
	else
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "no valid Accounts found") : printf("CheckMailD <no valid Accounts found>\n");

		return 0;
	}
}

/******************************************************************************
 * DecodeBase64
 ******************************************************************************/

void DecodeBase64(char *encodedstring, int encodedlen)
{
	int src_index, dst_index;
	char decodingtable[] = {62, -1, -1, -1, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -1, -1, -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51};

	memset(decodedstring, 0, sizeof(decodedstring));

	for(src_index = dst_index = 0; src_index < encodedlen; src_index += 4, dst_index += 3)
	{
		decodedstring[dst_index] = decodingtable[encodedstring[src_index] - 43] << 2 | ((decodingtable[encodedstring[1 + src_index] - 43] >> 4) & 3);

		if(encodedstring[2 + src_index] == '=')
		{
			break;
		}

		decodedstring[1 + dst_index] = decodingtable[encodedstring[1 + src_index] - 43] << 4 | ((decodingtable[encodedstring[2 + src_index] - 43] >> 2) & 15);

		if(encodedstring[3 + src_index] == '=')
		{
			break;
		}

		decodedstring[2 + dst_index] = decodingtable[encodedstring[2 + src_index] - 43] << 6 | decodingtable[encodedstring[3 + src_index] - 43];
	}

	memcpy(&header[stringindex], decodedstring, strlen(decodedstring));

	stringindex += strlen(decodedstring);
}

/******************************************************************************
 * DecodeQuotedPrintable
 ******************************************************************************/

void DecodeQuotedPrintable(char *encodedstring, int encodedlen)
{
	int src_index = 0, dst_index = 0;

	memset(decodedstring, 0, sizeof(decodedstring));

	while(src_index < encodedlen)
	{
		if(encodedstring[src_index] == '_')
		{
			decodedstring[dst_index++] = ' ';
		}
		else if(encodedstring[src_index] == '=')
		{
			int value;

			sscanf(&encodedstring[++src_index], "%2X", &value);

			src_index++;

			sprintf(&decodedstring[dst_index++], "%c", value);
		}
		else
		{
			decodedstring[dst_index++] = encodedstring[src_index];
		}

		src_index++;
	}

	memcpy(&header[stringindex], decodedstring, strlen(decodedstring));

	stringindex += strlen(decodedstring);
}

/******************************************************************************
 * DecodeHeader
 ******************************************************************************/
 
int DecodeHeader(char *encodedstring)
{
	char *ptrS, *ptrE;

	if((ptrS = strstr(encodedstring, "?B?")))
	{
		ptrS += 3;

		if((ptrE = strstr(ptrS, "?=")))
		{
			DecodeBase64(ptrS, ptrE - ptrS);

			return ptrE+2 - encodedstring;
		}
	}
	else if((ptrS = strstr(encodedstring, "?Q?")))
	{
		ptrS += 3;

		if((ptrE = strstr(ptrS, "?=")))
		{
			DecodeQuotedPrintable(ptrS, ptrE - ptrS);

			return ptrE+2 - encodedstring;
		}
	}

	return 1;
}

/******************************************************************************
 * SendPOPCommand (0=fail, 1=done)
 ******************************************************************************/

int SendPOPCommand(int command, char *param)
{
	struct hostent *server;
	struct sockaddr_in SockAddr;
	FILE *fd_log;
	char send_buffer[SENDBUFFER_SIZE], recv_buffer[RECVBUFFER_SIZE], month[4];
	char *ptr, *ptr1, *ptr2;
	int day, hour, minute;
	int linelen;
	char* portpos;


	// build commandstring

		switch(command)
		{
			case INIT:
				strcpy(send_buffer,param);
				// check if port is given
				portpos = strchr( send_buffer, ':');
				if( portpos )
				{
					*portpos = '\0';
					portpos++;
				}
						
				if(!(server = gethostbyname(send_buffer)))
				{
				    slog ? syslog(LOG_DAEMON | LOG_INFO, "could not resolve Host \"%s\", will try again in 10s", send_buffer) : printf("CheckMailD <could not resolve Host \"%s\", will try again in 10s>\n", send_buffer);

				    sleep(10);	/* give some routers a second chance */

				    if(!(server = gethostbyname(send_buffer)))
				    {
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not resolve Host \"%s\"", send_buffer) : printf("CheckMailD <could not resolve Host \"%s\">\n", send_buffer);

					return 0;
				    }
				}

				if((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
				{
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not create Socket") : printf("CheckMailD <could not create Socket>\n");

					return 0;
				}

				SockAddr.sin_family = AF_INET;
				if( portpos )
				{
					SockAddr.sin_port = htons(atoi(portpos));
				}
				else
				{
					SockAddr.sin_port = htons(110);
				}
				SockAddr.sin_addr = *(struct in_addr*) server->h_addr_list[0];

				if(connect(sock, (struct sockaddr*)&SockAddr, sizeof(SockAddr)))
				{
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not connect to Host \"%s\"", param) : printf("CheckMailD <could not connect to Host \"%s\">\n", param);

					close(sock);

					return 0;
				}

				break;

			case USER:
				sprintf(send_buffer, "USER %s\r\n", param);
				break;

			case PASS:
				sprintf(send_buffer, "PASS %s\r\n", param);
				break;

			case STAT:
				sprintf(send_buffer, "STAT\r\n");
				break;

			case UIDL:
				sprintf(send_buffer, "UIDL %s\r\n", param);
				break;

			case TOP:
				sprintf(send_buffer, "TOP %s 0\r\n", param);
				break;

			case RETR:
				sprintf(send_buffer, "TOP %s 5000\r\n", param);
				break;

			case DELE:
				sprintf(send_buffer, "DELE %s\r\n", param);
				break;

			case RSET:
				sprintf(send_buffer, "RSET\r\n");
				break;

			case QUIT:
				sprintf(send_buffer, "QUIT\r\n");
		}

		// send command to server
		if(command != INIT)
		{
			if(logging == 'Y')
			{
				if((fd_log = fopen(LOGFILE, "a")))
				{
					fprintf(fd_log, "POP3 <- %s", send_buffer);

					fclose(fd_log);
				}
				else
				{
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not log POP3-Command") : printf("CheckMailD <could not log POP3-Command>\n");
				}
			}

			send(sock, send_buffer, strlen(send_buffer), 0);
		}

		// get server response
		stringindex = 0;
		linelen = 0;
    	state = cNorm;
    	nStrich = 0;
    	nStartSpalte = 1;
    	nCharInLine = 0;
    	nCharInWord = 0;
    	cLast = 0;
    	nRead = nWrite = 0;
    	fPre = 0;
    	fHtml = 0;
    					
		while(recv(sock, &recv_buffer[stringindex], 1, 0) > 0)
		{
			if(command == TOP || command == RETR) // maz
			{
				if((recv_buffer[stringindex] == '\n') || (recv_buffer[stringindex] == '\r'))
				{
					// Eine Zeile eingelesen... x=0
					linelen = 0;
				}
				linelen++; // x-pos ...
				
				if(recv_buffer[stringindex] == '\n' && recv_buffer[stringindex - 3] == '\n')
				{				
					recv_buffer[stringindex+1] = '\0';					
					break;
				}			
			}
			else if(recv_buffer[stringindex] == '\n')
			{
				recv_buffer[stringindex+1] = '\0';
				break;
			}

			if(stringindex < sizeof(recv_buffer) - 4)
			{
				//if((linelen < 100) || (command != TOP))		// restrict linelen
				//{
					stringindex++;
				//} 
			}
			else
			{
				slog ? syslog(LOG_DAEMON | LOG_INFO, "Buffer Overflow") : printf("CheckMailD <Buffer Overflow>\n");
				recv_buffer[stringindex + 1] = '\0';
				break;
			}
		}

		//printf("\n%s\n", recv_buffer);
		if(logging == 'Y')
		{
			if((fd_log = fopen(LOGFILE, "a")))
			{
				fprintf(fd_log, "POP3 -> %s", recv_buffer);

				fclose(fd_log);
			}
			else
			{
				slog ? syslog(LOG_DAEMON | LOG_INFO, "could not log POP3-Response") : printf("CheckMailD <could not log POP3-Response>\n");
			}
		}

		// check server response
		if(!strncmp(recv_buffer, "+OK", 3))
		{
			switch(command)
			{
				case STAT:
					sscanf(recv_buffer, "+OK %d", &messages);
					break;

				case UIDL:
					sscanf(recv_buffer, "+OK %*d %s", uid);
					break;

				case TOP:
					stringindex = 0;
					headersize = strlen(recv_buffer);
					memset(header, 0, sizeof(header));

					if((ptr = strstr(recv_buffer, "\nDate:")))
					{
						ptr += 6;

						while(*ptr == ' ')
						{
							ptr++;
						}

						if(*ptr < '0' || *ptr > '9')
						{
							sscanf(ptr, "%*s %d %s %*d %d:%d", &day, &month[0], &hour, &minute);
						}
						else
						{
							sscanf(ptr, "%d %s %*d %d:%d", &day, &month[0], &hour, &minute);
						}

						sprintf(header, "%.2d.%.3s|%.2d:%.2d|", day, month, hour, minute);
						stringindex += 13;
					}
					else
					{
						memcpy(header, "??.???|??:??|", 13);
						stringindex += 13;
					}
		
					if((ptr = strstr(recv_buffer, "\nFrom:")))
					{
						ptr += 6;

						while(*ptr == ' ')
						{
							ptr++;
						}

						ptr1 = &header[stringindex];

						while(*ptr != '\r')
						{
							if(*ptr == '=' && *(ptr + 1) == '?')
							{
								ptr += DecodeHeader(ptr);

								/* skip space(s) between encoded words */

								ptr2 = ptr;

								while(*ptr2 == ' ')
								{
									ptr2++;
								}

								if(*ptr2 == '?' && *(ptr2 + 1) == '=')
								{
									ptr = ptr2;
								}
							}
							else
							{
								memcpy(&header[stringindex++], ptr++, 1);
							}
						}

						header[stringindex++] = '|';
					}
					else
					{
						memcpy(&header[stringindex], "-?-|", 4);
						stringindex += 4;
					}

					if((ptr = strstr(recv_buffer, "\nSubject:")))
					{
						ptr += 9;

						while(*ptr == ' ')
						{
							ptr++;
						}

						while(*ptr != '\r')
						{
							if(*ptr == '=' && *(ptr + 1) == '?')
							{
								ptr += DecodeHeader(ptr);

								/* skip space(s) between encoded words */

								ptr2 = ptr;

								while(*ptr2 == ' ')
								{
									ptr2++;
								}

								if(*ptr2 == '?' && *(ptr2 + 1) == '=')
								{
									ptr = ptr2;
								}
							}
							else
							{
								memcpy(&header[stringindex++], ptr++, 1);
							}
						}

						header[stringindex++] = '|';
					}
					else
					{
						memcpy(&header[stringindex], "-?-|", 4);
						stringindex += 4;
					}
					header[stringindex] = '\0';

					break;
		
					
				case RETR:															
					// Split Header/Body
					ptr = strstr(recv_buffer, "\r\n\r\n");					
					memset(body, 0, sizeof(body));
					memset(head, 0, sizeof(head));
					
					if(ptr!=NULL)					
					{
						// Ok! Body and Header splitted...
						memcpy(body, ptr, strlen(ptr));
						ptr[0] = '\0';
						memcpy(head, recv_buffer, sizeof(head));
						
					}
					else
					{
						// Error! Cannot split :/ - just save everything to body and header...
						memcpy(body, recv_buffer, strlen(recv_buffer));
						memcpy(header, recv_buffer, strlen(recv_buffer));
					}				
					break;

				case QUIT:
					close(sock);
			}
		}
		else
		{
			if((ptr = strchr(recv_buffer, '\r')))
			{
				*ptr = 0;
			}

			slog ? syslog(LOG_DAEMON | LOG_INFO, "Server Error (%s)", recv_buffer + 5) : printf("CheckMailD <Server Error (%s)>\n", recv_buffer + 5);

			close(sock);

			return 0;
		}

	return 1;
}

/******************************************************************************
 * SendIMAPCommand (0=fail, 1=done)
 ******************************************************************************/

int SendIMAPCommand(int command, char *param, char *param2)
{
	struct hostent *server;
	struct sockaddr_in SockAddr;
	FILE *fd_log;
	char send_buffer[SENDBUFFER_SIZE], recv_buffer[RECVBUFFER_SIZE], month[4];
	int day, hour, minute;
	
	char *ptr, *ptr1, *ptr2;
	int linelen;
	char* portpos;
	
		// build commandstring
		switch(command)
		{
			case INIT:

				strcpy(send_buffer,param);
				// check if port is given
				portpos = strchr( send_buffer, ':');
				if( portpos )
				{
					*portpos = '\0';
					portpos++;
				}
	
				server=gethostbyname(send_buffer);
				
				if(!server)
				{
				    slog ? syslog(LOG_DAEMON | LOG_INFO, "could not resolve Host \"%s\", will try again in 10s", param) : printf("CheckMailD <could not resolve Host \"%s\", will try again in 10s>\n", param);

				    sleep(10);	/* give some routers a second chance */

				    if(!(server = gethostbyname(send_buffer)))
				    {
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not resolve Host \"%s\"", send_buffer) : printf("CheckMailD <could not resolve Host \"%s\">\n", send_buffer);

					return 0;
				    }
				}

				if((sock = socket(AF_INET, SOCK_STREAM, 0)) == -1)
				{
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not create Socket") : printf("CheckMailD <could not create Socket>\n");

					return 0;
				}

				SockAddr.sin_family = AF_INET;
				if( portpos )
				{
					SockAddr.sin_port = htons(atoi(portpos));
				}
				else
				{
					SockAddr.sin_port = htons(143);
				}
				SockAddr.sin_addr = *(struct in_addr*) server->h_addr_list[0];

				if(connect(sock, (struct sockaddr*)&SockAddr, sizeof(SockAddr)))
				{
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not connect to Host \"%s\"", param) : printf("CheckMailD <could not connect to Host \"%s\">\n", param);

					close(sock);

					return 0;
				}

				break;

			case LOGIN:
				sprintf(send_buffer, "? LOGIN %s %s\r\n",param, param2);
				break;

			case SELECT:
				if( param[0]=='\0' )
				{
					sprintf(send_buffer, "? SELECT INBOX\r\n");
				}
				else
				{
					sprintf(send_buffer, "? SELECT %s\r\n", param);
				}
				break;

			case UIDL:
				sprintf(send_buffer, "? FETCH %s UID\r\n",param);				
				break;

			case FLAGS:
				sprintf(send_buffer, "? FETCH %s FLAGS\r\n",param);
				break;

			case UNSEEN:
				sprintf(send_buffer, "? STORE %s -FLAGS (\\Seen)\r\n",param);
				break;

			case FETCH:
				sprintf(send_buffer, "? FETCH %s (FLAGS BODY[HEADER.FIELDS (DATE FROM SUBJECT)])\r\n", param);				
				break;

			case DELE:
				sprintf(send_buffer, "? STORE %s +FLAGS (\\Deleted)\r\n",param);
				break;

			case EXPUNGE:
				sprintf(send_buffer, "? EXPUNGE\r\n");
				break;

			case RETR:				
				sprintf(send_buffer, "? FETCH %s BODY.PEEK[TEXT]<0.5000>\r\n", param);
				break;

			case CLOSE:
				sprintf(send_buffer, "? CLOSE\r\n");
				break;

			case LOGOUT:
				sprintf(send_buffer, "? LOGOUT\r\n");
				break;
		}

		// send command to server
		if(command != INIT)
		{
			if(logging == 'Y')
			{
				if((fd_log = fopen(LOGFILE, "a")))
				{
					fprintf(fd_log, "IMAP <- %s", send_buffer);
					fclose(fd_log);
				}
				else
				{
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not log IMAP-Command") : printf("CheckMailD <could not log IMAP-Command>\n");
				}
			}

			send(sock, send_buffer, strlen(send_buffer), 0);
		}

		// get server response
		stringindex = 0;
		linelen = 0;
   		state = cNorm;
   		nStrich = 0;
   		nStartSpalte = 1;
   		nCharInLine = 0;
   		nCharInWord = 0;
   		cLast = 0;
   		nRead = nWrite = 0;
   		fPre = 0;
   		fHtml = 0;

		while(recv(sock, &recv_buffer[stringindex], 1, 0) > 0)
		{			
			// read line by line and end if leading character hast been '?' or after one line after INIT
			if(recv_buffer[stringindex] == '\n')
			{
				if((recv_buffer[nRead] == '?') || (command == INIT))
				{
					recv_buffer[stringindex + 1] = '\0';
					break;
				}
				else
				{
					nRead=stringindex + 1;
				}
			}
	
			if(stringindex < sizeof(recv_buffer))
			{
				stringindex++;
			}
			else
			{
				slog ? syslog(LOG_DAEMON | LOG_INFO, "Buffer Overflow") : printf("CheckMailD <Buffer Overflow>\n");
				recv_buffer[stringindex + 1] = '\0';
				break;
			}				
		}	

		if(logging == 'Y')
		{
			if((fd_log = fopen(LOGFILE, "a")))
			{
				fprintf(fd_log, "IMAP -> %s", recv_buffer);
				fclose(fd_log);
			}
			else
			{
				slog ? syslog(LOG_DAEMON | LOG_INFO, "could not log IMAP-Response") : printf("CheckMailD <could not log IMAP-Response>\n");
			}
		}

		// check server response
		switch(command)
		{
			case INIT:
				
				if(!strncmp(recv_buffer, "* OK", 4))
				{
					return 1;
				}
				break;
				
			case LOGIN:
			case DELE:
			case CLOSE:
			case EXPUNGE:
			case UNSEEN:

				if(!strncmp(&recv_buffer[nRead], "? OK", 4))
				{
					return 1;
				}
				break;

			case SELECT:
					
				ptr1 = &recv_buffer[0];
				ptr2 = strstr(recv_buffer, "EXISTS");					
				do
				{
					ptr = strchr(ptr1,'\n');					
					if( ptr2 < ptr )
					{
						sscanf(ptr1, "* %d", &messages);
						break;
					}
					ptr1 = ptr + 1;
				} while( ptr );
			
				ptr2 = strstr(recv_buffer, "UIDVALIDITY");					
				sscanf(ptr2, "UIDVALIDITY %ld", &v_uid);

				if(!strncmp(&recv_buffer[nRead], "? OK", 4))
				{
					return 1;
				}
				break;

			case UIDL:			
				ptr2 = strstr(recv_buffer, "UID");
				if(ptr2!=NULL)
				{
					sscanf(ptr2, "UID %ld", &m_uid);
					sprintf(uid,"%08lX%08lX",v_uid,m_uid);

					if(!strncmp(&recv_buffer[nRead], "? OK", 4))
					{
						return 1;
					}								
				} else {
					return 1;
				}
				break;
				
			case FLAGS:
				// check if already seen
				if( strstr(recv_buffer, "\\Seen") != NULL )
				{
					*param2='S';
				}
				else
				{
					*param2='U';
				}					
				
				if(!strncmp(&recv_buffer[nRead], "? OK", 4))
				{
					return 1;
				}
				break;

			case FETCH:
				stringindex = 0;
				headersize = strlen(recv_buffer);
				memset(header, 0, sizeof(header));
				
				memset(head, 0, sizeof(head));							
				memcpy(head, recv_buffer, sizeof(head));

				
				if((ptr = strstr(recv_buffer, "\nDate:")))
				{
					ptr += 6;

					while(*ptr == ' ')
					{
						ptr++;
					}

					if(*ptr < '0' || *ptr > '9')
					{
						sscanf(ptr, "%*s %d %s %*d %d:%d", &day, &month[0], &hour, &minute);
					}
					else
					{
						sscanf(ptr, "%d %s %*d %d:%d", &day, &month[0], &hour, &minute);
					}

					sprintf(header, "%.2d.%.3s|%.2d:%.2d|", day, month, hour, minute);
					stringindex += 13;
					}
				else
				{
					memcpy(header, "??.???|??:??|", 13);
					stringindex += 13;
				}
		
				if((ptr = strstr(recv_buffer, "\nFrom:")))
				{
					ptr += 6;

					while(*ptr == ' ')
					{
						ptr++;
					}

					ptr1 = &header[stringindex];

					while(*ptr != '\r')
					{
						if(*ptr == '=' && *(ptr + 1) == '?')
						{
							ptr += DecodeHeader(ptr);

							/* skip space(s) between encoded words */

							ptr2 = ptr;

							while(*ptr2 == ' ')
							{
								ptr2++;
							}

							if(*ptr2 == '?' && *(ptr2 + 1) == '=')
							{
								ptr = ptr2;
							}
						}
						else
						{
							memcpy(&header[stringindex++], ptr++, 1);
						}
					}

					header[stringindex++] = '|';
				}
				else
				{
					memcpy(&header[stringindex], "-?-|", 4);
					stringindex += 4;
				}

				if((ptr = strstr(recv_buffer, "\nSubject:")))
				{
					ptr += 9;

					while(*ptr == ' ')
					{
						ptr++;
					}

					while(*ptr != '\r')
					{
						if(*ptr == '=' && *(ptr + 1) == '?')
						{
							ptr += DecodeHeader(ptr);

							/* skip space(s) between encoded words */

							ptr2 = ptr;

							while(*ptr2 == ' ')
							{
								ptr2++;
							}

							if(*ptr2 == '?' && *(ptr2 + 1) == '=')
							{
								ptr = ptr2;
							}
						}
						else
						{
							memcpy(&header[stringindex++], ptr++, 1);
						}
					}

					header[stringindex++] = '|';
				}
				else
				{
					memcpy(&header[stringindex], "-?-|", 4);
					stringindex += 4;
				}

				header[stringindex] = '\0';
				
				if(!strncmp(&recv_buffer[nRead], "? OK", 4))
				{
					return 1;
				}
				break;
					
			case RETR:		
				memset(body, 0, sizeof(body));
				memcpy(body, recv_buffer, sizeof(recv_buffer));								
				return 1;
					
			case LOGOUT:
				close(sock);
				return 1;
					
			default:
				slog ? syslog(LOG_DAEMON | LOG_INFO, "IMAP Server (%s)", recv_buffer) : printf("CheckMailD <IMAP Server (%s)>\n", recv_buffer);
				
		}

	slog ? syslog(LOG_DAEMON | LOG_INFO, "IMAP Server (%s)", recv_buffer) : printf("CheckMailD <IMAP Server (%s)>\n", recv_buffer);
	close(sock);
	return 0;
}

/******************************************************************************
 * CheckAccount (0=fail, 1=done)
 ******************************************************************************/

int CheckAccount(int account)
{
	int loop, minloop = 0;
	FILE *fd_status, *fd_idx;
	int filesize, skip_uid_check = 0;
	char *known_uids = 0, *ptr = 0;
	char mailnumber[12];
	int knownmails = 0;

	imap = 0;
		
	// timestamp

	time(&tt);
	strftime(timeinfo, 22, "%R", localtime(&tt));

	// check if we should use an IMAP server
	if( account_db[account].imap[0] != '\0' )
	{
		imap = 1;

		// init connection to server
		if(!SendIMAPCommand(INIT, account_db[account].imap, ""))
		{
			return 0;
		}

		// login to mail server
		if(!SendIMAPCommand(LOGIN, account_db[account].user, account_db[account].pass))
		{
			return 0;
		}
		
		// select folder, get mail count and UID
		if(!SendIMAPCommand(SELECT, account_db[account].inbox, ""))
		{
			return 0;
		}
	}
	else
	{
		// get mail count
		if(!SendPOPCommand(INIT, account_db[account].pop3))
		{
			return 0;
		}

		if(!SendPOPCommand(USER, account_db[account].user))
		{
			return 0;
		}

		if(!SendPOPCommand(PASS, account_db[account].pass))
		{
			return 0;
		}

		if(!SendPOPCommand(STAT, ""))
		{
			return 0;
		}

		if(!SendPOPCommand(RSET, ""))
		{
			return 0;
		}
	}
	
		account_db[account].mail_all = messages;
		account_db[account].mail_new = 0;
		account_db[account].mail_unread = 0;
		account_db[account].mail_read = 0;
		deleted_messages = 0;

		// get mail info		
		STATUSFILE[strlen(STATUSFILE) - 1] = account | '0';

		if(messages)
		{
			// load last status from file

				if((fd_status = fopen(STATUSFILE, "r")))
				{
					fseek(fd_status, 0, SEEK_END);

					if((filesize = ftell(fd_status)))
					{
						known_uids = malloc(filesize + 1);
						memset(known_uids, 0, filesize + 1);

						rewind(fd_status);
						fread(known_uids, filesize, 1, fd_status);
					}
					else
					{
						slog ? syslog(LOG_DAEMON | LOG_INFO, "empty Status for Account %d", account) : printf("CheckMailD <empty Status for Account %d>\n", account);
						skip_uid_check = 1;
					}

					fclose(fd_status);
				}
				else
				{
					slog ? syslog(LOG_DAEMON | LOG_INFO, "no Status for Account %d", account) : printf("CheckMailD <no Status for Account %d>\n", account);
					skip_uid_check = 1;
				}

				// clear status			
				if(!(fd_status = fopen(STATUSFILE, "w")))
				{
					slog ? syslog(LOG_DAEMON | LOG_INFO, "could not create Status for Account %d", account) : printf("CheckMailD <could not create Status for Account %d>\n", account);
				}
				
				fd_idx = fopen(IDXFILE, "w+");
				
				// generate listing
				if(fd_status)
				{
					fprintf(fd_status, "- --:-- %s ---/---\n", account_db[account].name); /* reserve space */
				}

				for(loop = messages; loop != minloop; loop--)
				{
					sprintf(mailnumber, "%d", loop);

					if( !imap )
					{
						if(!SendPOPCommand(UIDL, mailnumber))
						{
							free(known_uids);
	
							if(fd_status)
							{
								fclose(fd_status);
							}
	
							return 0;
						}
					}
					else
					{
						if(!SendIMAPCommand(UIDL, mailnumber, ""))
						{
							free(known_uids);
	
							if(fd_status)
							{
								fclose(fd_status);
							}
	
							return 0;
						}
					}

					if(skip_uid_check)
					{
						char seen;
						if( !imap )
						{
							if(!SendPOPCommand(TOP, mailnumber))
							{
								free(known_uids);
	
								if(fd_status)
								{
									fclose(fd_status);
								}
	
								return 0;
							}
							
							// maz - Receive POP3 message
							if(recvmail != 'N')
							{								
								SendPOPCommand(RETR, mailnumber);							
							}
							// maz - end				
						}
						else
						{
							/* char seen; */
							if(!SendIMAPCommand(FLAGS, mailnumber, &seen))
							{
								free(known_uids);
	
								if(fd_status)
								{
									fclose(fd_status);
								}
	
								return 0;
							}
							

							if(!SendIMAPCommand(FETCH, mailnumber, ""))
							{
								free(known_uids);
	
								if(fd_status)
								{
									fclose(fd_status);
								}
	
								return 0;
							}						
						
							// maz - Receive IMAP message
							if(recvmail != 'N')
							{								
								SendIMAPCommand(RETR, mailnumber, "");
							}
							// maz - End mail

							if( seen == 'U' )
							{
								if(!SendIMAPCommand(UNSEEN, mailnumber, ""))
								{
									free(known_uids);
		
									if(fd_status)
									{
										fclose(fd_status);
									}
	
									return 0;
								}					
							}
							
						}

						if (fd_idx)
						{
							fprintf(fd_idx,"|%4d|%s\n",loop,uid);
						}
						
						if(fd_status)
						{
							// maz - check if email was already received													
							if(known_uids != NULL) 
							{
								if((ptr = strstr(known_uids, uid)))
								{								
									seen = 'U';
								} 
							}
							else 
							{											
							  seen = 'U';
							}
							// maz - end
							
							if ( seen == 'U' )
							{
								fprintf(fd_status, "|N|%s|%s\n", uid, header);
								account_db[account].mail_new++;														
								
								// maz - Mail-Event: New mail received			
								if(cfgnot == 'Y')
								{										
									char*newHeader = malloc(strlen(header) + strlen(uid) + 2);
									sprintf(newHeader, "%s|%s", uid, header);
									MailEvent(account, account_db[account].mail_all, account_db[account].mail_new, newHeader, false, 0);
									free(newHeader);
								}
								// maz - end
							}
							else							
							{
								fprintf(fd_status, "|O|%s|%s\n", uid, header);									
							}							
						}												
					}
					else
					{					
						if((ptr = strstr(known_uids, uid)))
						{
							knownmails++;
						
							// maz - old mail:						
							if(cfgnot == 'Y')
							{							
								char*ptr2=strchr(ptr,'\n');						
								if (ptr2 != NULL)
								{								
									if((ptr2 - ptr) > 0)
									{
										char*header = malloc(ptr2-ptr+1);
										strncpy(header, ptr, ptr2 - ptr);						
										header[ptr2-ptr] = '\0';
															
										if(header != NULL)
										{											
											// Mail-Event: Old Mail received
											MailEvent(account, account_db[account].mail_all, account_db[account].mail_new, header, true, 0);
										}														
										
										free(header);	
									}
								}						
							}
																					
							if(*(ptr - 2) == 'D')
							{
								if( !imap )
								{
									if(!SendPOPCommand(DELE, mailnumber))
									{
										free(known_uids);
	
										if(fd_status)
										{
											fclose(fd_status);
										}
	
										return 0;
									}
								}
								else
								{
									if(!SendIMAPCommand(DELE, mailnumber, ""))
									{
										free(known_uids);
	
										if(fd_status)
										{
											fclose(fd_status);
										}
	
										return 0;
									}
								}

								deleted_messages++;
							}
							else 
							{
								if(fd_status)
								{
									/* for all new and unseen mails
									 * check flag on server */
									if((*(ptr - 2) == 'N') || (*(ptr - 2) == 'n'))
									{
										if(!imap) 											
										{			
											// maz
											fprintf(fd_status, "|O|");
											account_db[account].mail_read++;
											// maz end
										} else 
										{										
											char seen;
											if(!SendIMAPCommand(FLAGS, mailnumber, &seen))
											{
												return 0;
											}
											if ( seen == 'U' )
											{
												fprintf(fd_status, "|n|");
												account_db[account].mail_unread++;												
											}
											else
											{
												fprintf(fd_status, "|O|");
												account_db[account].mail_read++;
											}																				
										}
									}
									else
									{
										fprintf(fd_status, "|O|");
									}
									
									while(*ptr != '\n')
									{
										fprintf(fd_status, "%c", *ptr++);
									}

									fprintf(fd_status, "\n");
								}
							}
						}
						else
						{
							char seen;
							if( !imap )
							{
								if(!SendPOPCommand(TOP, mailnumber))
								{
									free(known_uids);
	
									if(fd_status)
									{
										fclose(fd_status);
									}
	
									return 0;
								}
								
								// maz - Receive POP3 message								
								if(recvmail != 'N')
								{									
									SendPOPCommand(RETR, mailnumber);
								}
								// maz - end				

							}
							else
							{
								if(!SendIMAPCommand(FLAGS, mailnumber, &seen))
								{
									free(known_uids);
		
									if(fd_status)
									{
										fclose(fd_status);
									}
		
									return 0;
								}

								if(!SendIMAPCommand(FETCH, mailnumber, ""))
								{
									free(known_uids);
	
									if(fd_status)
									{
										fclose(fd_status);
									}
	
									return 0;
								}

								// maz - Receive IMAP message
								if(recvmail != 'N')
								{									
									SendIMAPCommand(RETR, mailnumber, "");
								}
								// maz - End mail								
								
								if( seen == 'U' )
								{
									if(!SendIMAPCommand(UNSEEN, mailnumber, ""))
									{
										free(known_uids);
			
										if(fd_status)
										{
											fclose(fd_status);
										}
		
										return 0;
									}					
								}
							}

							if (fd_idx)
							{
								fprintf(fd_idx,"|%4d|%s\n",loop,uid);
							}
							
							if(fd_status)
							{
								// maz - check if email was already received															
								if(known_uids != NULL) 
								{
									if(!(ptr = strstr(known_uids, uid)))
									{
										seen = 'U';									
									} 							
								} 
								else 
								{														  
								  seen = 'U';
								}
								// maz - end
								
								if ( seen == 'U' )
								{
									fprintf(fd_status, "|N|%s|%s\n", uid, header);
									account_db[account].mail_new++;
									
									// maz - Mail-Event: New mail received:
									if(cfgnot == 'Y')
									{
										char*newHeader = malloc(strlen(header) + strlen(uid) + 2);
										sprintf(newHeader, "%s|%s", uid, header);										
										MailEvent(account, account_db[account].mail_all, account_db[account].mail_new, newHeader, false, 0);
										free(newHeader);									
									}
									// maz - end								
								}
								else
								{
									fprintf(fd_status, "|O|%s|%s\n", uid, header);																	
								}
							}							
						}
					}
				}
				
				if(fd_status)
				{
					rewind(fd_status);
					fprintf(fd_status, "%.1d %s %s %.3d/%.3d\n", account, timeinfo, account_db[account].name, account_db[account].mail_new + account_db[account].mail_unread, account_db[account].mail_all - deleted_messages);
				}

				free(known_uids);

				if(fd_idx)
				{
					fclose(fd_idx);
				}
				
				if(fd_status)
				{
					fclose(fd_status);
				}
		}
		else
		{
			account_db[account].mail_new = 0;

			if((fd_status = fopen(STATUSFILE, "w")))
			{
				fprintf(fd_status, "%.1d %s %s 000/000\n", account, timeinfo, account_db[account].name);

				fclose(fd_status);
			}
			else
			{
				slog ? syslog(LOG_DAEMON | LOG_INFO, "could not create Status for Account %d", account) : printf("CheckMailD <could not create Status for Account %d>\n", account);
			}
		}

	// close session

		if( !imap )
		{
			if(!SendPOPCommand(QUIT, ""))
			{
				return 0;
			}	
		}
		else
		{
			if(!SendIMAPCommand(EXPUNGE, "", ""))
			{
				return 0;
			}	
			if(!SendIMAPCommand(CLOSE, "", ""))
			{
				return 0;
			}	
			if(!SendIMAPCommand(LOGOUT, "", ""))
			{
				return 0;
			}	
		}
		
	// for POP3 all Messages are new due to missing Status
	if ( !imap )
	{		
		account_db[account].mail_unread = messages;	
	}
	
	return 1;
}

// replaces double-quotes through single-quotes
void RemoveQuotes(char *cvalue)
{	
	int i;
	
	for(i=0; i<strlen(cvalue); i++)
	{
		if(cvalue[i] == '"')
			cvalue[i] = '\'';
	}
}

/******************************************************************************
* SCRIPT: MAIL-EVENT
   Only occurs, when a new mail is received.
   The mail-header and -body is written to maillog.head and maillog.body
 ******************************************************************************/
void MailEvent(int account, int mail_all, int mail_new, char*header, bool oldMail, int isInterval)
{		
	FILE* mailf;
	unsigned int  count = 0;	
	char* cSplit[256];	      // 256 byte are too much... but i'm a little bit sceptical :D
	char* ptr;
	char* cmd;	
	int i;
	
	
	// do not (!) fire the event for old mails...
	if(oldMail)
		return;	
		
	// New Mail-Event (called, for every new mail arrived)
	// -------------------------------------------------------------------------------
	if(!isInterval)
	{
		ptr = strtok(header, "|");			
						
		// split Header
		while (ptr != NULL)
		{			
			cSplit[count] = (char*)malloc(strlen(ptr)+1);
			memset(cSplit[count], 0, strlen(ptr)+1);
			strcpy(cSplit[count], ptr);		
						
			RemoveQuotes(cSplit[count]);
			
			ptr = strtok(NULL, "|");
			count++;

			if(count > sizeof(cSplit) / sizeof(char*))
				break;
		}

		// perhaps, not all parameters catched... fill them up!
		while(count!=5 && count <= 5)
		{
			cSplit[count] = (char*)malloc(strlen(ptr)+1);
			memset(cSplit[count], 0, strlen(ptr)+1);
			count++;
		}
					
		// got all parameters.
		if(count>=5)
		{				
			// ------------------------------------------------------
			// save eMail body & head in separate files
			// ------------------------------------------------------		
			// save mail-body to BODYFILE (maillog..body)
			mailf = fopen(BODYFILE, "w");
			if(mailf != NULL)
			{
				fputs(body, mailf);
				fclose(mailf);					
			}
			
			// save mail-header to HEADFILE (maillog.head)
			mailf = fopen(HEADFILE, "w");
			if(mailf != NULL)
			{
				fputs(head, mailf);
				fclose(mailf);		
			}
			
			// ------------------------------------------------------
			// call maillog.cfg script
			// ------------------------------------------------------					
			cmd = malloc(strlen(account_db[account].name) + strlen(cSplit[0]) + strlen(cSplit[1]) + strlen(cSplit[2]) + strlen(cSplit[3]) + strlen(cSplit[4]) + 64);
			memset(cmd, 0, strlen(account_db[account].name) + strlen(cSplit[0]) + strlen(cSplit[1]) + strlen(cSplit[2]) + strlen(cSplit[3]) + strlen(cSplit[4]) + 64);			
			sprintf(cmd, "%s%s %d %d %d \"%s\" \"%s\" \"%s\" \"%s\" \"%s\" \"%s\"", CFGPATH, EVFILE_NAME, isInterval, mail_all, mail_new, account_db[account].name, cSplit[0], cSplit[1], cSplit[2], cSplit[3], cSplit[4]);
			slog ? syslog(LOG_DAEMON | LOG_INFO, "NewMail-Event: %s%s (%s)!\n", CFGPATH, EVFILE_NAME, cmd) : printf("CheckMailD <NewMail-Event: %s%s (%d)>\n", CFGPATH, EVFILE_NAME, mail_new);		
			system(cmd);
			free(cmd);

			// ------------------------------------------------------		
			// remove email body & head file...
			// ------------------------------------------------------					
			remove(BODYFILE);
			remove(HEADFILE);
		} 
		
		// free resources 				
		for(i=0; i<count; i++)
		{
			if(cSplit[i]!=NULL)
			{
				realloc(cSplit[i], 1);
				cSplit[i] = NULL;
			} else {
				break;
			}
		}			
	} 
		
	// Interval-Event (for status) - called every INTERVALL=X min 
	// -------------------------------------------------------------------------------
	else 
	{	
		// ------------------------------------------------------
		// call maillog.cfg script
		// ------------------------------------------------------			
		cmd = malloc(256);
		memset(cmd, 0, 256);			
		sprintf(cmd, "%s%s %d %d %d",  CFGPATH, EVFILE_NAME, isInterval, mail_all, mail_new);
		slog ? syslog(LOG_DAEMON | LOG_INFO, "Status-Event:  %s%s (%s)!\n",  CFGPATH, EVFILE_NAME, cmd) : printf("CheckMailD <Status-Event:  %s%s (%d)>\n",  CFGPATH, EVFILE_NAME, mail_all);		
		system(cmd);
		free(cmd);
	}
				
	return;
}

/******************************************************************************
 * PHONE-EVENT
 ******************************************************************************/
int TelEvent(char *fon, char *sip, char *num) 
{
	char buffer[256];
	time(&tt);
	strftime(timeinfo, 22, "%H", localtime(&tt));
	timeofday = atoi(timeinfo);
	if (timeofday < 8 || timeofday > 21)
		slog ? syslog(LOG_DAEMON | LOG_INFO, "No ring at night") : printf("CheckMailD <No ring at night>\n");	
	else
	{
		int mysocket;
		struct sockaddr_in dest;
		mysocket = socket(AF_INET, SOCK_STREAM, 0);
		dest.sin_family = AF_INET; 
		dest.sin_addr.s_addr = inet_addr("127.0.0.1"); /* Sets destination IP number */ 
		dest.sin_port = htons (PORTNUM); /* Sets destination port number */
		memset(&(dest.sin_zero), '\0', 8); /* Zeroes rest of struct */
		slog ? syslog(LOG_DAEMON | LOG_INFO, "Notify over Phone") : printf("CheckMailD <Notify over Phone>\n");
	 	connect(mysocket, (struct sockaddr *)&dest,sizeof(struct sockaddr));
		snprintf(buffer, sizeof(buffer)-1 ,"ATP%s\nATD*%s#%s\n", fon, sip, num);		
		/* Anruf aufbauen und 7 Sekunden warten */
		send(mysocket, buffer, strlen(buffer), 0);
	 	sleep(SLEEP);
	 	/* Anruf beenden */
	 	send(mysocket, "ath\n", 4, 0);
		close(mysocket);
	}
	return 0;
}


/******************************************************************************
 * LED-EVENT
 ******************************************************************************/
void LEDEvent(bool bOn, int unread_mails, char *ledmajor, char ledminor) 
{
	if(bOn)
	{	
		LEDOn(unread_mails, ledmajor, ledminor);
	}
	else
	{
		LEDOff(ledmajor);
	}
		
}

/******************************************************************************
 * LEDOn, LEDOff
 ******************************************************************************/
void LEDOn(int unread_mails, char *ledmajor, char ledminor) 
{
 	char buffer[22];
 	led_status = 1;
	buffer[0] = '\0';
	sprintf(buffer, "echo %s,%c > /var/led", ledmajor, ledminor);	
	system(buffer);
	slog ? syslog(LOG_DAEMON | LOG_INFO, "You have %d unread mail(s). Setting LED on.\n",unread_mails) : printf("CheckMailD <You have %d unread mail(s). Setting LED on.>\n",unread_mails);
}
  
void LEDOff(char *ledmajor)
{
	char buffer[22];
	led_status = 0;
	buffer[0] = '\0';
	sprintf(buffer, "echo %s,1 > /var/led", ledmajor);
	system(buffer);
	slog ? syslog(LOG_DAEMON | LOG_INFO, "No unread mail. Setting LED off.\n") : printf("CheckMailD <No unread mail. Setting LED off.>\n");
}
 	
	
/******************************************************************************
* NOTIFY-USER *
   Occurs every X min when checking for new mails.  Even if no new mails exists!
   Needful for checking the count of mails (new/unread). eg. LED-, phone-notify...
 ******************************************************************************/
void NotifyUser(int newmails, int oldmails)
{		
	//newmails = mailstatus;
	//oldmails = unread_mailstatus;
	
	int mails = newmails + oldmails;
	
	if ((led_status == 0) && (mails > 0 || newmails > 0))
	{		
		// set LED on
		if(lednot == 'Y')
			LEDEvent(true, mails, ledmajor, ledminor);			
		
		// Phone-Event (call phone)
		if (telnot == 'Y') 
			TelEvent(fon, sip, num);
	}
	
	if ((mails == 0 && newmails == 0)) 
	{
		// set LED off
		if(lednot == 'Y')
			LEDEvent(false, 0, ledmajor, 0);			
	}
	
	// Mail-Event (Intervall)
	if(cfgnot == 'Y')
	{		
		MailEvent(0, mails, newmails, "| | | | | ", false, 1);		
	}
			
	// first check if we have to remove old notifications	
	if(newmails == 0)				// we do not have new mails
	{
		if((oldmails == 0))			// we have no unread mails
		{
			unlink(NOTIFILE);		// clear notify-file
			return;
		}
									// no further processing in this mode
		return;
	}
	
	
// maz
//	    if(unlink(NOTIFILE))
//   		{
//	   		sum = mails;		
//   		}
//    	else
//    	{
//       		sum += mails;
//     	}
		
		
		//sum = mails;
// maz ende 
		
		// write notify-file (used by other programs to know the number of unread messages)				
		FILE* pipe;		
		pipe = fopen(NOTIFILE,"w");
		if( pipe != NULL)
		{
			fprintf(pipe, "%d", mails);
			fclose(pipe);
		}

}		

/******************************************************************************
 * SigHandler
 ******************************************************************************/

void SigHandler(int signal)
{
	switch(signal)
	{
		case SIGTERM:

			slog ? syslog(LOG_DAEMON | LOG_INFO, "shutdown") : printf("CheckMailD <shutdown>\n");

			intervall = 0;

			break;

		case SIGHUP:

			slog ? syslog(LOG_DAEMON | LOG_INFO, "update") : printf("CheckMailD <update>\n");

			if(!ReadConf())
			{
				intervall = 0;
			}

			break;

		case SIGUSR1:

			online = 1;

			if(slog)
			{
				syslog(LOG_DAEMON | LOG_INFO, "wakeup");
			}
			else
			{
				printf("CheckMailD <wakeup>\n");
			}
			
			break;
			
		case SIGUSR2:

			online = 0;
			
			if(slog)
			{
				syslog(LOG_DAEMON | LOG_INFO, "sleep");
			}
			else
			{
				printf("CheckMailD <sleep>\n");
			}
	}
}

/******************************************************************************
 * Daemonize
 ******************************************************************************/

void daemonize()
{
	int i,lfp;
	char str[10];
	if(getppid()==1) return; /* already a daemon */
	i=fork();
	if (i<0) exit(1); /* fork error */
	if (i>0) exit(0); /* parent exits */
	/* child (daemon) continues */
	setsid(); /* obtain a new process group */
	for (i=getdtablesize();i>=0;--i) close(i); /* close all descriptors */
	i=open("/dev/null",O_RDWR); dup(i); dup(i); /* handle standart I/O */
	umask(027); /* set newly created file permissions */
	//chdir(RUNNING_DIR); /* change running directory */
	lfp=open(LOCK_FILE,O_RDWR|O_CREAT,0640);
	if (lfp<0) exit(1); /* can not open */
	//if (lockf(lfp,F_TLOCK,0)<0) exit(0);  /*can not lock */ 
	/* first instance continues */
	sprintf(str,"%d\n",getpid());
	write(lfp,str,strlen(str)); /* record pid to lockfile */
	signal(SIGCHLD,SIG_IGN); /* ignore child */
	signal(SIGTSTP,SIG_IGN); /* ignore tty signals */
	signal(SIGTTOU,SIG_IGN);
	signal(SIGTTIN,SIG_IGN);
	signal(SIGHUP,SigHandler); /* catch hangup signal */
	signal(SIGTERM,SigHandler); /* catch kill signal */
	signal(SIGUSR1,SigHandler);
	signal(SIGUSR2,SigHandler);
}


/******************************************************************************
 * MainProgram
 ******************************************************************************/

int main(int argc, char **argv)
{	
	int param, account, nodelay = 0, help = 0;
	slog = 0;
	
	// check commandline parameter	
	if(argc > 1)
	{
		for(param = 1; param < argc; param++)
		{
			if(!strcmp(argv[param], "-nodelay"))
			{
				nodelay = 1;
			}
			else if(!strcmp(argv[param], "-daemon"))
			{
				slog = 1;
			}
			else if(!strcmp(argv[param], "-single"))
			{
				slog = 0;
			}
			else if(!strcmp(argv[param], "-path"))
			{
				if(argv[param+1]!=NULL)
				{
					CFGPATH = (char*)malloc(strlen(argv[param+1])+2);											
					memset(CFGPATH, 0, strlen(argv[param+1])+2);
					strncpy(CFGPATH, argv[param+1], strlen(argv[param+1]));
										
					if(CFGPATH[strlen(CFGPATH)-1] != '/')					
						strcat(CFGPATH, "/");															
				}
			}
			else if(!strcmp(argv[param], "-help") || !strcmp(argv[param], "-?") || !strcmp(argv[param], "--help"))
			{
				help = 1;
			}
		}
	}	
  
	// default cfg-dir (/var/tmp)
	if(CFGPATH==NULL)
	{
		CFGPATH = (char*)malloc(strlen(CFGPATH_DEFAULT)+1);
		strcpy(CFGPATH, CFGPATH_DEFAULT);					
	} 
   
  
  	// cat path to files...
	// checkmaild.new
	NOTIFILE = (char*)malloc(strlen(NOTIFILE_NAME) + strlen(CFGPATH) + 1);
	memset(NOTIFILE, 0, strlen(NOTIFILE_NAME) + strlen(CFGPATH) + 1);
	sprintf(NOTIFILE, "%s%s", CFGPATH, NOTIFILE_NAME);
	// maillog.body
	BODYFILE = (char*)malloc(strlen(BODYFILE_NAME) + strlen(CFGPATH) + 1);
	memset(BODYFILE, 0, strlen(BODYFILE_NAME) + strlen(CFGPATH) + 1);
	sprintf(BODYFILE, "%s%s", CFGPATH, BODYFILE_NAME);
	// maillog.head
	HEADFILE = (char*)malloc(strlen(HEADFILE_NAME) + strlen(CFGPATH) + 1);
	memset(HEADFILE, 0, strlen(HEADFILE_NAME) + strlen(CFGPATH) + 1);
	sprintf(HEADFILE, "%s%s", CFGPATH, HEADFILE_NAME);
	// maillog.cfg
	EVFILE = (char*)malloc(strlen(EVFILE_NAME) + strlen(CFGPATH) + 1);
	memset(EVFILE, 0, strlen(EVFILE_NAME) + strlen(CFGPATH) + 1);
	sprintf(EVFILE, "%s%s", CFGPATH, EVFILE_NAME);
	// checkmaild.idx
	IDXFILE = (char*)malloc(strlen(IDXFILE_NAME) + strlen(CFGPATH) + 1);
	memset(IDXFILE, 0, strlen(IDXFILE_NAME) + strlen(CFGPATH) + 1);
	sprintf(IDXFILE, "%s%s", CFGPATH, IDXFILE_NAME);
	// checkmaild.?
	STATUSFILE = (char*)malloc(strlen(STATUSFILE_NAME) + strlen(CFGPATH) + 1);
	memset(STATUSFILE, 0, strlen(STATUSFILE_NAME) + strlen(CFGPATH) + 1);
	sprintf(STATUSFILE, "%s%s", CFGPATH, STATUSFILE_NAME);	
		
  	// maz
	if(help)
	{
		printf("                                                                             \n");
		printf("CheckMailD v0.4.1                                                            \n");
		printf("-----------------------------------------------------------------------------\n");
		printf("usage: checkmaild [options]                                                  \n");		
		printf("                                                                             \n");
		printf(" -daemon              start in daemon-mode (with syslog)                     \n");
		printf(" -single              start in single-mode (without syslog)                  \n");
		printf(" -nodelay             no start delay                                         \n");
		printf(" -path [PATH]         config/data-path (default: %s)                  \n", CFGPATH);
		printf(" -help, -?            this help                                              \n");
		printf("                                                                             \n");
		
		return -1;
	}
	// maz end
		
	// create daemon				
	time(&tt);
	strftime(timeinfo, 22, "%d.%m.%Y - %T", localtime(&tt));
	
	/* only daemonize when logging to syslog */
	if (slog)
	{	
		openlog("CheckMailD", LOG_ODELAY, LOG_DAEMON);
		daemonize();
	}

	// read, update or create config
	if(!ReadConf())
	{
		return -1;
	}

	// check for running daemon
	if((fd_pid = fopen(PIDFILE, "r+")))
	{
		fscanf(fd_pid, "%d", &pid);

		if(kill(pid, 0) == -1 && errno == ESRCH)
		{
			pid = getpid();

			rewind(fd_pid);
			fprintf(fd_pid, "%d", pid);
			fclose(fd_pid);
		}
		else
		{
			slog ? syslog(LOG_DAEMON | LOG_INFO, "Daemon already running with PID %d", pid) : printf("CheckMailD <Daemon already running with PID %d>\n", pid);
			fclose(fd_pid);
			return -1;
		}
	}
	else
	{
		pid = getpid();

		fd_pid = fopen(PIDFILE, "w");
		fprintf(fd_pid, "%d", pid);
		fclose(fd_pid);
	}

	// install sighandler
	if(signal(SIGTERM, SigHandler) == SIG_ERR)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "Installation of Signalhandler for TERM failed") : printf("CheckMailD <Installation of Signalhandler for TERM failed>\n");

		return -1;
	}

	if(signal(SIGHUP, SigHandler) == SIG_ERR)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "Installation of Signalhandler for HUP failed") : printf("CheckMailD <Installation of Signalhandler for HUP failed>\n");

		return -1;
	}

	if(signal(SIGUSR1, SigHandler) == SIG_ERR)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "Installation of Signalhandler for USR1 failed") : printf("CheckMailD <Installation of Signalhandler for USR1 failed>\n");

		return -1;
	}

	if(signal(SIGUSR2, SigHandler) == SIG_ERR)
	{
		slog ? syslog(LOG_DAEMON | LOG_INFO, "Installation of Signalhandler for USR2 failed") : printf("CheckMailD <Installation of Signalhandler for USR2 failed>\n");

		return -1;
	}

	// remove any notification file
	unlink(NOTIFILE);	
	// check accounts

	if(!nodelay)
	{
		sleep(startdelay);
	}

	do
	{
		if(online)
		{
			if(logging == 'Y' && logmode == 'S')
			{
				fclose(fopen(LOGFILE, "w"));
			}

			mailstatus = 0;
			unread_mailstatus = 0;
			if (!inPOPCmd)
			{
				inPOPCmd = 1;
				for(account = 0; account < accounts; account++)
				{
					if(CheckAccount(account))
					{
						slog ? syslog(LOG_DAEMON | LOG_INFO, "Account %d = %.3d(%.3d)/%.3d Mail(s) for %s", account, account_db[account].mail_new, account_db[account].mail_unread, account_db[account].mail_all - deleted_messages, account_db[account].name) : printf("CheckMailD <Account %d = %.3d(%.3d)/%.3d Mail(s) for %s>\n", account, account_db[account].mail_new, account_db[account].mail_unread, account_db[account].mail_all - deleted_messages, account_db[account].name);

						mailstatus += account_db[account].mail_new;					
						unread_mailstatus += account_db[account].mail_unread;					
						
						// pop3 -> subtract newmail from unread_mail
						if(account_db[account].imap[0] == '\0' && account_db[account].mail_new != 0)
							unread_mailstatus -= account_db[account].mail_new;
						
					}
					else
					{
						slog ? syslog(LOG_DAEMON | LOG_INFO, "Account %d skipped", account) : printf("CheckMailD <Account %d skipped>\n", account);
					}
				}
				inPOPCmd = 0;
			}
			
			// NOTIFY-USER (LED/PHONE/CFG-EVENT)			
			NotifyUser(mailstatus, unread_mailstatus);
		}

		sleep(intervall * 60);
	}
	while(intervall);

	// cleanup		
	unlink(PIDFILE);
	free(CFGPATH);	
	free(IDXFILE);
	free(BODYFILE);
	free(HEADFILE);
	free(NOTIFILE);
	free(EVFILE);
	
	/* LED Off */	
	if(lednot == 'Y')
		LEDOff(ledmajor);
	
	time(&tt);
	strftime(timeinfo, 22, "%d.%m.%Y - %T", localtime(&tt));
	slog ? syslog(LOG_DAEMON | LOG_INFO, "%s closed [%s]", versioninfo, timeinfo) : printf("CheckMailD %s closed [%s]\n", versioninfo, timeinfo);
	closelog();

	return 0;
}
