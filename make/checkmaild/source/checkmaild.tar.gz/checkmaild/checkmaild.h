/******************************************************************************
 *                       <<< CheckMailD - POP3 Daemon >>>
 *                       Copyright (C) 2006  Oliver Metz
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *-----------------------------------------------------------------------------
 ******************************************************************************/
 
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <pthread.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/un.h>
#include <syslog.h>
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include <stdarg.h>


#ifdef WIN32
#include <winsock.h>
#else
#include <unistd.h>
#include <sys/socket.h>
#include <netdb.h>
#include <arpa/inet.h>
#endif


#define CFGPATH "/mod/etc/"
#define RUNNING_DIR	"/var/tmp"
#define LOCK_FILE	"/var/lock/checkmail.lock"
#define CFGFILE "checkmaild.conf"
#define SCKFILE "/var/tmp/checkmaild.socket"
#define LOGFILE "/var/log/checkmaild.log"
#define PIDFILE "/var/run/checkmaild.pid"
#define POP3FILE "/var/tmp/checkmail.pop3"
#define NOTIFILE "/var/tmp/checkmail.new"

/* for testing 
#define CFGPATH "./"
#define RUNNING_DIR	"./"
#define LOCK_FILE	"checkmail.lock"
#define CFGFILE "checkmail.conf"
#define SCKFILE "checkmaild.socket"
#define LOGFILE "checkmaild.log"
#define PIDFILE "checkmaild.pid"
#define POP3FILE "checkmail.pop3"
#define NOTIFILE "checkmail.new"
*/

#define bool char
#define true 1
#define false 0

// maximum number of chars in a line
#define cnRAND  	78
// maximum charcters in a word
#define cnMaxWordLen	20

char statusfile[] = "/var/tmp/checkmail.?";
char idxfile[] = "/var/tmp/CheckMailD.idx";

/* for testing 
char statusfile[] = "checkmail.?";
char idxfile[] = "CheckMailD.idx";
*/

FILE *fd_mail;
int  nStartSpalte, nCharInLine, nCharInWord, nRead, nWrite, nStrich ; 
int  nIn, nSo, nTr; 
char  cLast; 
bool  fPre; 							//! pre-formated HTML code
bool  fHtml; 							//! HTML code
int  nCRLF = 0; 
int  nLine = 1; 
int  nRef  = 1;
int   nHyp  = 0 ;
char  sSond[355],sRef[355], sWord[85];
static enum  t_state { cNorm, cInTag, cSond, cInComment, cTrans } state ;

// pop3 and smtp commands

enum
{
	INIT, QUIT,
	USER, PASS, STAT, UIDL, TOP, DELE, RETR, RSET,
	EHLO, AUTH, MAIL, RCPT, DATA1, DATA2, DATA3,
	LOGIN, SELECT, FETCH, LOGOUT, CLOSE, FLAGS,
	UNSEEN, EXPUNGE
};

#define MAXMAIL 100													// should be the same in tuxmail.h

// account database

struct
{
	char name[32];
	char pop3[64];
	char imap[64];
	char user[64];
	char pass[64];
	char smtp[64];
	char from[64];
	char code[8];
	int  auth;
	char suser[64];
	char spass[64];
	char inbox[64];
	int  mail_all;
	int  mail_new;
	int  mail_unread;
	int  mail_read;

}account_db[10];

// spam database

struct
{
	char address[64];

}spamfilter[100];

// some data

char versioninfo[12];
FILE *fd_pid;
int slog = 1;
int pid;
char encodedstring[512], decodedstring[512];
int startdelay, intervall;
char logging, logmode, mailrd;
char online = 1;
char mailread = 0;
char inPOPCmd = 0;
int accounts;
int sock;
int messages, deleted_messages;
int led_status = 0;
int stringindex;
char uid[128];
long v_uid;
long m_uid;
char imap;
char header[1024];
int headersize;
char timeinfo[22];
time_t tt;
